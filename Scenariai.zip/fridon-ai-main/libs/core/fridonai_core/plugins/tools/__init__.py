from fridonai_core.plugins.tools.base import BaseTool

__all__ = ["BaseTool"]
