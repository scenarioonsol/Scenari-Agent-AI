from fridonai_core.crons.base import BaseCron

__all__ = ["BaseCron"]
