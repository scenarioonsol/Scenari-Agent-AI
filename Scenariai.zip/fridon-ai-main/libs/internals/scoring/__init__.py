from libs.internals.scoring.calculate_score import calculate_score

__all__ = ["calculate_score"]
