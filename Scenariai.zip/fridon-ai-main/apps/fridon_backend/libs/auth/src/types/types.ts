export type WalletSession = {
  readonly walletAddress: string;
};
